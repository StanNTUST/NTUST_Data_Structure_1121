/***********************************************************************
 * File: hw1-1.cpp
 * Author: JiaHong-Wang
 * Create Date: 2023-10-02
 * Editor: JiaHong-Wang
 * Update Date: 2023-10-04
 * Description: compute taxis and seat
 * ***********************************************************************/
#include<iostream>
#include<string>
#include<cctype>
using namespace std;

struct stack {
	int* weights;
	int count;
	struct stack* next=NULL;
	void push(int number[], int count) {
		this->count = count;
		weights = new int(count + 1);
		for (int i = 0; i < count; i++) {
			weights[i] = number[i];
		}
	}
	void print() {
		for (int i = 0; i < count; i++) {
			cout<<weights[i]<<" ";
		}
	}
};

int main() {
	string text;
	int number, numbers[2000], count = 0, weight = 0,total=0;
	stack* newStack, *top=NULL;
	while (getline(cin, text)) if (text != "") break;
	while (text != "") {
		number = stoi(text.substr(0, text.find(" ")));

		if (weight + number <= 200) {
			weight += number;
			numbers[count] = number;
			count++;
			if (text == text.substr(text.find(" ") + 1, text.length())) break;
		}
		else {
			total++;
			newStack = new stack();
			newStack->push(numbers, count);
			newStack->next = top;
			top = newStack;

			weight = number;
			numbers[0] = number;
			count = 1;

			if (text == text.substr(text.find(" ") + 1, text.length())) break;
		}

		text = text.substr(text.find(" ") + 1, text.length());
	}
	total++;
	newStack = new stack();
	newStack->push(numbers, count);
	newStack->next = top;
	top = newStack;

	cout<<total<<endl;
	while (top != NULL) {
		top->print();
		top=top->next;
	}
}
